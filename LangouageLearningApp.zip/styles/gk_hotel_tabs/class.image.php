<?php

/**
* @author: GavickPro
* @copyright: 2008-2014
**/
	
// no direct access
defined('_JEXEC') or die('Restricted access');

class GKIS_HotelTabs_Image extends GKIS_Image {

}

/* eof */