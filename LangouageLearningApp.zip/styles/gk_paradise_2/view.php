<?php

/**
* GK Image Show - view file
* @package Joomla!
* @Copyright (C) 2009-2012 Gavick.com
* @ All rights reserved
* @ Joomla! is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version $Revision: GK4 1.0 $
**/

// no direct access
defined('_JEXEC') or die;

jimport('joomla.utilities.string');

JHtml::stylesheet(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_paradise_2/owlcarousel/css/owl.carousel.min.css');

JHtml::script(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_paradise_2/owlcarousel/js/owl.carousel.min.js');


$ImgData = $this->config['image_show_data'];
$module_id = $this->config['module_id'];
$generate_thumbnails = $this->config['generate_thumbnails'];
$gk_paradise_2_animation_speed = $this->config['config']->gk_paradise_2->gk_paradise_2_animation_speed;
$gk_paradise_2_autoanimation = $this->config['config']->gk_paradise_2->gk_paradise_2_autoanimation;
$gk_paradise_2_show_arrow = $this->config['config']->gk_paradise_2->gk_paradise_2_show_arrow;
$gk_paradise_2_show_pagination = $this->config['config']->gk_paradise_2->gk_paradise_2_show_pagination;

$autoplay = ($gk_paradise_2_autoanimation == 1) ? 'true' : 'false';
$dots = ($gk_paradise_2_show_pagination == 1) ? 'true' : 'false';
$nav = ($gk_paradise_2_show_arrow == 1) ? 'true' : 'false';

if($this->config['random_slides'] == 1) {
	shuffle($ImgData);
}

// Image Show
$listImg = array_filter($ImgData, function($img) {
	return !!$img->published;
});
?>

<div id="gkIs-<?php echo $module_id;?>" class="gkIsWrapper-gk_paradise_2">
	<div class="owl-carousel<?php echo (($gk_paradise_2_show_pagination == 1) ? ' has-dots' : ''); ?>">
		<?php foreach ($listImg as $item): ?>
			<?php
				if($generate_thumbnails == 1) {
					$thumbnail = GKIS_Paradise_2_Image::translateName($item->image, $module_id);
					$path = JUri::root().'modules/mod_image_show_gk4/cache/'.$thumbnail;
				} else {
					$path = JUri::root() . $item->image;
				}

				if($item->type == "k2"){
					if(isset($this->articlesK2[$item->artK2_id])) {
						$title = htmlspecialchars($this->articlesK2[$item->artK2_id]["title"]);
						$content = $title;
				  	$link =  $this->articlesK2[$item->artK2_id]["link"];
				  } else {
				  	$title = 'Selected article doesn\'t exist!';
				  	$content = $title;
				  	$link = '#';
				  }
				} else {
				   // creating slide title
					$title = htmlspecialchars(($item->type == "text") ? $item->name : $this->articles[$item->art_id]["title"]);

					// creating slie content
					$content = ($item->type == "text") ? $item->content : $title;
					$content = str_replace(array('[leftbracket]', '[rightbracket]', '[ampersand]'), array('<', '>', '&amp;'), $content);

					// creating slide link
					$link = ($item->type == "text") ? $item->url : $this->articles[$item->art_id]["link"];
				}
			?>

			<?php echo ($link !== "" ? '<a href="'. $link .'">' : '') ?>
			<img src="<?php echo $path; ?>" alt="<?php echo ($item->alt !== '' ? $item->alt : $item->name); ?>">
			<?php echo ($link !== "" ? '</a>' : '') ?>
		<?php endforeach; ?>
	</div>
</div>


<script>
	jQuery(document).ready(function($) {
		$("#gkIs-<?php echo $module_id;?> .owl-carousel").owlCarousel({
			addClassActive: true,
			autoplay: <?php echo $autoplay; ?>,
			autoplaySpeed: <?php echo $gk_paradise_2_animation_speed; ?>,
			autoplayHoverPause: true,
			center: true,
			dots: <?php echo $dots; ?>,
			items: 1,
			loop: true,
			margin: 150,
			nav: <?php echo $nav; ?>,
			navText: [" ", " "]
		});
	});
</script>