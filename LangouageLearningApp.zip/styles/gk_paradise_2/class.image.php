<?php

/**
* @author: GavickPro
* @copyright: 2008-2012
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

class GKIS_Paradise_2_Image extends GKIS_Image {

}

/* eof */