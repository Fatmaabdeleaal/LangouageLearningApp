<?php

/**
* @author: GavickPro
* @copyright: 2008-2012
**/
	
// no direct access
defined('_JEXEC') or die('Restricted access');

class GKIS_Shop_and_Buy_Image extends GKIS_Image {

}

/* eof */