jQuery(window).on('load', function () {
    jQuery(".gkIsWrapper-gk_musicstate").each(function (i, _el) {
        let el = jQuery(_el);
        var elID = el.attr("id");
        var wrapper = jQuery('#' + elID);
        var $G = $Gavick[elID];
        var slides = [];
        var links = [];
        var imagesToLoad = [];
        var swipe_min_move = 30;
        var swipe_max_time = 500;
        // animation variables
        $G['animation_timer'] = false;
        // blank flag
        $G['blank'] = false;
        // load the images
        wrapper.find('figure').each(function (i, _el) {
            let el = jQuery(_el);
            var newImg = jQuery('<img/>', {
                "title": el.data('title'),
                "class": 'gkIsSlide',
                "style": 'z-index: ' + el.data('zindex') + ';',
                "src": el.data('url')
            });
            links[i] = el.data('link');
            imagesToLoad.push(newImg);
            newImg.prependTo(el);
            newImg.on('load', function () {
                newImg.attr('complete', true);
            })
            newImg.attr('src', el.data('url'));
        });

        var time = setInterval(function () {
            var process = 0;
            imagesToLoad.forEach(function (elm) {
                var elm = jQuery(elm);
                if (elm.attr('complete')) {
                    var wrap = elm.parent();

                    var newImgLayer = jQuery('<div>', {
                        "title": elm.data('title'),
                        "class": 'gkIsSlide',
                        "style": 'z-index: ' + elm.data('zindex') + '; background-image: url(\'' + elm.attr('src') + '\')'
                    });

                    newImgLayer.prependTo(wrap);

                    if (i > 0) {
                        newImgLayer.parent().css('opacity', 0);
                    }

                    elm.appendTo(newImgLayer);
                    process++;
                }
            });

            if (process == imagesToLoad.length) {
                clearInterval(time);
                wrapper.find('.gkIsSlide img').each(function (i, img) {
                    jQuery(img).remove();
                });

                setTimeout(function () {
                    wrapper.find('.gkIsPreloader').css({ "position": "absolute", "opacity": "0", "display": "none" });
                }, 400);

                $G['actual_slide'] = 0;

                wrapper.find('figure').first().addClass('active');
                wrapper.find('figure').first().css('opacity', 1);
                wrapper.css('height', 'auto');

                wrapper.addClass('loaded');

                wrapper.find(".gkIsSlide").each(function (i, elmt) {
                    slides[i] = elmt;
                });

                if ($G['slide_links']) {
                    wrapper.find('.gkIsSlide').on("click", function (e) {
                        window.location = links[$G['actual_slide']];
                    });
                    wrapper.find('.gkIsSlide').css('cursor', 'pointer');
                }

                wrapper.find('.gkIsPagination li').each(function (i, item) {
                    var item = jQuery(item);
                    item.on('click', function () {
                        if (i != $G['actual_slide']) {
                            $G['blank'] = true;
                            gk_musicstate_autoanimate($G, wrapper, 'next', i);
                        }
                    });

                    item.on('mouseenter', function () {
                        var label = item.find('small');
                        label.css('transition', 'all .25s');
                        var x = label.outerWidth() + 1;
                        setTimeout(function () {
                            label.css({ 'left': -1 * x, 'opacity': 1 });
                        }, 150);
                    });

                    item.on('mouseleave', function () {
                        var label = item.find('small');
                        setTimeout(function () {
                            label.css({ 'left': 0, 'opacity': 0 });
                        }, 150);
                    });
                });

                if (slides.length > 1) {
                    // auto-animation
                    if ($G['autoanim'] == 1) {
                        $G['animation_timer'] = setTimeout(function () {
                            gk_musicstate_autoanimate($G, wrapper, 'next', null);
                        }, $G['anim_interval']);
                    }

                    // pagination
                    var slide_pos_start_x = 0;
                    var slide_pos_start_y = 0;
                    var slide_time_start = 0;
                    var slide_swipe = false;

                    wrapper.on('touchstart', function (e) {
                        slide_swipe = true;

                        if (e.changedTouches.length > 0) {
                            slide_pos_start_x = e.changedTouches[0].pageX;
                            slide_pos_start_y = e.changedTouches[0].pageY;
                            slide_time_start = new Date().getTime();
                        }
                    });

                    wrapper.on('touchmove', function (e) {
                        if (e.changedTouches.length > 0 && slide_swipe) {
                            if (
                                Math.abs(e.changedTouches[0].pageX - slide_pos_start_x) > Math.abs(e.changedTouches[0].pageY - slide_pos_start_y)
                            ) {
                                e.preventDefault();
                            } else {
                                slide_swipe = false;
                            }
                        }
                    });

                    wrapper.on('touchend', function (e) {
                        if (e.changedTouches.length > 0 && slide_swipe) {
                            if (
                                Math.abs(e.changedTouches[0].pageX - slide_pos_start_x) >= swipe_min_move &&
                                new Date().getTime() - slide_time_start <= swipe_max_time
                            ) {
                                if (e.changedTouches[0].pageX - slide_pos_start_x > 0) {
                                    $G['blank'] = true;
                                    gk_musicstate_autoanimate($G, wrapper, 'prev', null);
                                } else {
                                    $G['blank'] = true;
                                    gk_musicstate_autoanimate($G, wrapper, 'next', null);
                                }
                            }
                        }
                    });
                }
            }
        }, 500);
    });
});

var gk_musicstate_animate = function ($G, wrapper, imgPrev, imgNext) {
    //
    var imgPrev = jQuery(imgPrev);
    var imgNext = jQuery(imgNext);
    imgPrev.addClass('inactive');
    setTimeout(function () {
        imgPrev.removeClass('inactive');
    }, 500);
    //
    imgNext.css('opacity', 1);
    //
    imgPrev.animate({
        opacity: 0
    }, $G['anim_speed'], function () {
        imgPrev.removeClass('active');
        //imgPrev.css('opacity', 1);

        imgNext.addClass('active');
        if ($G['autoanim'] == 1) {
            clearTimeout($G['animation_timer']);

            $G['animation_timer'] = setTimeout(function () {
                if ($G['blank']) {
                    $G['blank'] = false;
                    clearTimeout($G['animation_timer']);

                    $G['animation_timer'] = setTimeout(function () {
                        gk_musicstate_autoanimate($G, wrapper, 'next', null);
                    }, $G['anim_interval']);
                } else {
                    gk_musicstate_autoanimate($G, wrapper, 'next', null);
                }
            }, $G['anim_interval']);
        }
    });
};

var gk_musicstate_autoanimate = function ($G, wrapper, dir, next) {
    var wrapper = jQuery(wrapper);
    var i = $G['actual_slide'];
    var imgs = wrapper.find('figure');

    if (next == null) {
        next = (dir == 'next') ? ((i < imgs.length - 1) ? i + 1 : 0) : ((i == 0) ? imgs.length - 1 : i - 1); // dir: next|prev
    }

    gk_musicstate_animate($G, wrapper, imgs[i], imgs[next]);
    $G['actual_slide'] = next;

    wrapper.find('.gkIsPagination li').removeClass('active');
    jQuery(wrapper.find('.gkIsPagination li').get(next)).addClass('active');
};
