<?php

/**
* @author: GavickPro
* @copyright: 2008-2012
**/

// no direct access
defined('_JEXEC') or die('Restricted access');

class GKIS_Paradise_1_Image extends GKIS_Image {

}

/* eof */