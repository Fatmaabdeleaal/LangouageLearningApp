<?php

/**
* GK Image Show - view file
* @package Joomla!
* @Copyright (C) 2009-2012 Gavick.com
* @ All rights reserved
* @ Joomla! is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version $Revision: GK4 1.0 $
**/

// no direct access
defined('_JEXEC') or die;

jimport('joomla.utilities.string');

JHtml::stylesheet(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_paradise_1/owlcarousel/css/animate.min.css');
JHtml::stylesheet(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_paradise_1/owlcarousel/css/owl.carousel.min.css');

JHtml::script(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_paradise_1/owlcarousel/js/owl.carousel.min.js');


$ImgData = $this->config['image_show_data'];
$module_id = $this->config['module_id'];
$generate_thumbnails = $this->config['generate_thumbnails'];
$gk_paradise_1_animation_speed = $this->config['config']->gk_paradise_1->gk_paradise_1_animation_speed;
$gk_paradise_1_autoanimation = $this->config['config']->gk_paradise_1->gk_paradise_1_autoanimation;
$gk_paradise_1_show_arrow = $this->config['config']->gk_paradise_1->gk_paradise_1_show_arrow;
$gk_paradise_1_show_pagination = $this->config['config']->gk_paradise_1->gk_paradise_1_show_pagination;

$autoplay = ($gk_paradise_1_autoanimation == 1) ? 'true' : 'false';
$dots = ($gk_paradise_1_show_pagination == 1) ? 'true' : 'false';
$nav = ($gk_paradise_1_show_arrow == 1) ? 'true' : 'false';

if($this->config['random_slides'] == 1) {
	shuffle($ImgData);
}

// Image Show
$listImg = array_filter($ImgData, function($img) {
	return !!$img->published;
});
?>

<div id="gkIs-<?php echo $module_id;?>" class="gkIsWrapper-gk_paradise_1 owl-carousel">
	<?php foreach ($listImg as $item): ?>
		<?php
			if($generate_thumbnails == 1) {
				$thumbnail = GKIS_Paradise_1_Image::translateName($item->image, $module_id);
				$path = JUri::root().'modules/mod_image_show_gk4/cache/'.$thumbnail;
			} else {
				$path = JUri::root() . $item->image;
			}

			if($item->type == "k2"){
				if(isset($this->articlesK2[$item->artK2_id])) {
					$title = htmlspecialchars($this->articlesK2[$item->artK2_id]["title"]);
					$content = $title;
			  	$link =  $this->articlesK2[$item->artK2_id]["link"];
			  } else {
			  	$title = 'Selected article doesn\'t exist!';
			  	$content = $title;
			  	$link = '#';
			  }
			} else {
			   // creating slide title
				$title = htmlspecialchars(($item->type == "text") ? $item->name : $this->articles[$item->art_id]["title"]);

				// creating slie content
				$content = ($item->type == "text") ? $item->content : $title;
				$content = str_replace(array('[leftbracket]', '[rightbracket]', '[ampersand]'), array('<', '>', '&amp;'), $content);

				// creating slide link
				$link = ($item->type == "text") ? $item->url : $this->articles[$item->art_id]["link"];
			}
		?>

		<div class="gk-img-item" style="background-image: url('<?php echo $path; ?>');">
			<?php if ($link !== "") : ?>
				<a href="<?php echo $link; ?>">
					<span class="invisible"><?php echo ($item->alt !== 'paradise-item' ? $item->alt : $item->name); ?></span>
				</a>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>


<script>
	jQuery(document).ready(function($) {
		$("#gkIs-<?php echo $module_id;?>.owl-carousel").owlCarousel({
			addClassActive: true,
			autoplay: <?php echo $autoplay; ?>,
			autoplaySpeed: <?php echo $gk_paradise_1_animation_speed; ?>,
			autoplayHoverPause: true,
			dots: <?php echo $dots; ?>,
			items: 1,
			loop: true,
			nav : <?php echo $nav; ?>,
			navText : [" ", " "]
		});
	});
</script>