<?php

/**
* @author: GavickPro
* @copyright: 2008-2015
**/
	
// no direct access
defined('_JEXEC') or die('Restricted access');

class GKIS_Quark_Image extends GKIS_Image {

}

/* eof */