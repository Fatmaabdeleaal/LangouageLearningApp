<?php

/**
* GK Image Show - view file
* @package Joomla!
* @Copyright (C) 2009-2012 Gavick.com
* @ All rights reserved
* @ Joomla! is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version $Revision: GK4 1.0 $
**/

// no direct access
defined('_JEXEC') or die;

jimport('joomla.utilities.string');
JHtml::stylesheet(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_wedding_2/owl.carousel.min.css');
JHtml::script(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_wedding_2/owl.carousel.min.js');


$ImgData = $this->config['image_show_data'];
$module_id = $this->config['module_id'];
$generate_thumbnails = $this->config['generate_thumbnails'];

// die('<pre>'.print_r($ImgData, 1).'</pre>');

if($this->config['random_slides'] == 1) {
	shuffle($ImgData);
}

// Image Show
$listImg = array_filter($ImgData, function($img) {
	return !!$img->published;
});

$finaList = array_chunk($listImg, 2);
?>

<div id="gkIs-<?php echo $module_id;?>" class="gkIsWrapper-gk_wedding_2 owl-carousel">
	<!-- <div class="gkIsPreloader">Loading&hellip;</div> -->

	<?php foreach ($finaList as $group): ?>
		<div class="gk-img-slide-group">
			<?php foreach ($group as $item): ?>
				<?php
				if($generate_thumbnails == 1) {
					$thumbnail = GKIS_Couple_2_Image::translateName($item->image, $module_id);
					$path = JUri::root().'modules/mod_image_show_gk4/cache/'.$thumbnail;
				} else {
					$path = JUri::root() . $item->image;
				}

				if($item->type == "k2"){
					if(isset($this->articlesK2[$item->artK2_id])) {
						$title = htmlspecialchars($this->articlesK2[$item->artK2_id]["title"]);
						$content = $title;
				  	$link =  $this->articlesK2[$item->artK2_id]["link"];
				  } else {
				  	$title = 'Selected article doesn\'t exist!';
				  	$content = $title;
				  	$link = '#';
				  }
				} else {
				   // creating slide title
					$title = htmlspecialchars(($item->type == "text") ? $item->name : $this->articles[$item->art_id]["title"]);

					// creating slie content
					$content = ($item->type == "text") ? $item->content : $title;
					$content = str_replace(array('[leftbracket]', '[rightbracket]', '[ampersand]'), array('<', '>', '&amp;'), $content);

					// creating slide link
					$link = ($item->type == "text") ? $item->url : $this->articles[$item->art_id]["link"];
				}
				?>

				<div class="gk-img-item">
					<?php echo ($link !== "" ? '<a href="'. $link .'">' : '') ?>
					<img src="<?php echo $path; ?>" alt="<?php echo ($item->alt !== '' ? $item->alt : $item->name); ?>">
					<?php echo ($link !== "" ? '</a>' : '') ?>
				</div>

			<?php endforeach; ?>
		</div>
	<?php endforeach;?>
</div>
<script>
	jQuery(document).ready(function($) {
		$("#gkIs-<?php echo $module_id;?>.owl-carousel").owlCarousel({
			addClassActive: true,
			items: 4,
			margin: 36,
			responsive : {
				0 : {
					items: 1,
				},

				768 : {
					items: 2,
				},

				979 : {
					items: 2,
				},

				1199 : {
					items: 4,
				}
			},
			loop: true,
			nav : false,
			navText : ["<span class='ion-chevron-left'></span>", "<span class='ion-chevron-right'></span>"],
			dots: false,
			autoplay: true,
			slideTransition: 'linear',
			autoplaySpeed: 35000,
			autoplayHoverPause: true
		});
	});
</script>