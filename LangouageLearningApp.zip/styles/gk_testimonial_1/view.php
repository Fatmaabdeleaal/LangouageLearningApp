<?php

/**
* GK Image Show - view file
* @package Joomla!
* @Copyright (C) 2009-2012 Gavick.com
* @ All rights reserved
* @ Joomla! is Free Software
* @ Released under GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
* @ version $Revision: GK4 1.0 $
**/

// no direct access
defined('_JEXEC') or die;

jimport('joomla.utilities.string');

JHtml::stylesheet(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_testimonial_1/slick/slick.css');

JHtml::script(JUri::root() . 'modules/mod_image_show_gk4/styles/gk_testimonial_1/slick/slick.min.js');


$ImgData = $this->config['image_show_data'];
$module_id = $this->config['module_id'];
$generate_thumbnails = $this->config['generate_thumbnails'];
$gk_testimonial_1_animation_speed = $this->config['config']->gk_testimonial_1->gk_testimonial_1_animation_speed;
$gk_testimonial_1_autoanimation = $this->config['config']->gk_testimonial_1->gk_testimonial_1_autoanimation;
$gk_testimonial_1_show_arrow = $this->config['config']->gk_testimonial_1->gk_testimonial_1_show_arrow;
$gk_testimonial_1_show_pagination = $this->config['config']->gk_testimonial_1->gk_testimonial_1_show_pagination;

$autoplay = ($gk_testimonial_1_autoanimation == 1) ? 'true' : 'false';
$dots = ($gk_testimonial_1_show_pagination == 1) ? 'true' : 'false';
$nav = ($gk_testimonial_1_show_arrow == 1) ? 'true' : 'false';

if($this->config['random_slides'] == 1) {
	shuffle($ImgData);
}

// Image Show
$listImg = array_filter($ImgData, function($img) {
	return !!$img->published;
});
?>

<div id="gkIs-<?php echo $module_id;?>" class="gkIsWrapper-gk_testimonial_1">
	<div class="slick-content">
		<?php foreach ($listImg as $item): ?>
			<?php
				if($item->type == "k2"){
					if(isset($this->articlesK2[$item->artK2_id])) {
						$title = htmlspecialchars($this->articlesK2[$item->artK2_id]["title"]);
						$content = $title;
				  } else {
				  	$title = 'Selected article doesn\'t exist!';
				  	$content = $title;
				  }
				} else {
				   // creating slide title
					$title = htmlspecialchars(($item->type == "text") ? $item->name : $this->articles[$item->art_id]["title"]);

					// creating slie content
					$content = ($item->type == "text") ? $item->content : $title;
					$content = str_replace(array('[leftbracket]', '[rightbracket]', '[ampersand]'), array('<', '>', '&amp;'), $content);
				}
			?>

			<div class="item">
					<?php echo $content; ?>
			</div>
		<?php endforeach; ?>
	</div>

	<div class="slick-nav">
		<?php foreach ($listImg as $item): ?>
			<?php
				if($generate_thumbnails == 1) {
					$thumbnail = GKIS_Testimonial_1_Image::translateName($item->image, $module_id);
					$path = JUri::root().'modules/mod_image_show_gk4/cache/'.$thumbnail;
				} else {
					$path = JUri::root() . $item->image;
				}
			?>

			<div class="item">
				<img src="<?php echo $path; ?>" alt="<?php echo ($item->alt !== '' ? $item->alt : $item->name); ?>">
			</div>
		<?php endforeach; ?>
	</div>

	<div class="slick-title">
		<?php foreach ($listImg as $item): ?>
			<?php
				if($item->type == "k2"){
					if(isset($this->articlesK2[$item->artK2_id])) {
						$title = htmlspecialchars($this->articlesK2[$item->artK2_id]["title"]);
				  	$link =  $this->articlesK2[$item->artK2_id]["link"];
				  } else {
				  	$title = 'Selected article doesn\'t exist!';
				  	$link = '#';
				  }
				} else {
				   // creating slide title
					$title = htmlspecialchars(($item->type == "text") ? $item->name : $this->articles[$item->art_id]["title"]);

					// creating slide link
					$link = ($item->type == "text") ? $item->url : $this->articles[$item->art_id]["link"];
				}

				$find = array("[", "]");
				$replace = array("<span>", "</span>");
				$title = str_replace($find, $replace, $title);
			?>

			<h4>
				<?php echo ($link !== "" ? '<a href="'. $link .'">' : '') ?>
				<?php echo $title; ?>
				<?php echo ($link !== "" ? '</a>' : '') ?>
			</h4>
		<?php endforeach; ?>
	</div>
</div>


<script>
	jQuery(document).ready(function($) {
		$('.slick-content').slick({
		  slidesToShow: 1,
		  slidesToScroll: 1,
		  arrows: <?php echo $nav; ?>,
		  prevArrow:'<span class="slick-prev"></span>',
		  nextArrow:'<span class="slick-next"></span>',
		  asNavFor: '.slick-nav, .slick-title',
		  fade: true
		});

		$('.slick-title').slick({
		  slidesToShow: 1,
		  slidesToScroll: 1,
		  asNavFor: '.slick-nav, .slick-content',
		  arrows: false,
		  dots: <?php echo $dots; ?>,
		  autoplay: <?php echo $autoplay; ?>,
  		autoplaySpeed: <?php echo $gk_testimonial_1_animation_speed; ?>,
		  fade: true
		});

		$('.slick-nav').slick({
		  slidesToShow: 3,
		  slidesToScroll: 1,
		  asNavFor: '.slick-content, .slick-title',
		  arrows: false,
		  centerMode: true,
		  focusOnSelect: true,
		  variableWidth: true
		});
	});
</script>