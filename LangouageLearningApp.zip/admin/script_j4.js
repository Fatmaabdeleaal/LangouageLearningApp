(function ($) {
    $current_slide = 0;
    $currently_opened = 0;
    jQuery(document).ready($ => {
        var add_form = $('#gk_tab_add_form');
        var json_data_to_parse = $('#jform_params_image_show_data').html();
        var module_style = jQuery('#jform_params_module_style').val();
        if (json_data_to_parse == '') {
            json_data_to_parse = '[]';
        }
        var tabs = JSON.parse(json_data_to_parse);
        if (tabs == null || tabs == '') tabs = [];
        var json_config_to_parse = $('#jform_params_config').html();
        if (json_config_to_parse == '') {
            json_config_to_parse = '[]';
        }
        var config = JSON.parse(json_config_to_parse);
        if (config == null || config == '') config = {};

        jQuery('#module-form').addClass(module_style);
        $('ul.nav a[href="#options-IMAGE_SHOW_MANAGER"]').on('click', function () {
            setTimeout(function () {
                if ($('ul.nav a[href=#options-IMAGE_SHOW_MANAGER]').parent().hasClass('active')) {
                    $('.pane-slider').css('height', 'auto');
                }
            }, 750);
        });
        var public_text = add_form.find('.gk_tab_add_content_access option').first().html();
        var registered_text = add_form.find('.gk_tab_add_content_access option').eq(1).html();
        var module_text = add_form.find('.gk_tab_add_type option').eq(1).html();
        var article_text = add_form.find('.gk_tab_add_type option').first().html();
        var published_text = $('#invisible').find('.gk_tab_item_state span').first().html();
        var unpublished_text = $('#invisible').find('.gk_tab_item_state span').eq(1).html();
        var types = {};
		add_form.find('.gk_tab_add_type option').each((idx, el) => {
			types[el.value] = el.innerText;
		})
        $('invisible').find('.gk_tab_item_state span').remove();

        if (add_form.find('.gk_tab_add_type').val() == 'article') {
            add_form.find('.gk_tab_add_art').css('display', 'flex');
            add_form.find('.gk_tab_add_artK2').css('display', 'none');
            add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'none');
        } else if (add_form.find('.gk_tab_add_type').val() == 'gallery') {
            add_form.find('.gk_tab_add_art').css('display', 'none');
            add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_artK2').css('display', 'none');
            add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'flex');
        } else if (add_form.find('.gk_tab_add_type').val() == 'text') {
            add_form.find('.gk_tab_add_art').css('display', 'none');
            add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_artK2').css('display', 'none');
            add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'none');
        } else {
            add_form.find('.gk_tab_add_artK2').css('display', 'flex');
            add_form.find('.gk_tab_add_art').css('display', 'none');
            add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'none');
        }
        add_form.find('.gk_tab_add_type').on('change', function () {
            if (add_form.find('.gk_tab_add_type').val() == 'article') {
                add_form.find('.gk_tab_add_art').css('display', 'flex');
                add_form.find('.gk_tab_add_artK2').css('display', 'none');
                add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'none');
            } else if (add_form.find('.gk_tab_add_type').val() == 'gallery') {
                add_form.find('.gk_tab_add_art').css('display', 'none');
                add_form.find('.gk_tab_add_artK2').css('display', 'none');
                add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'flex');
            } else if (add_form.find('.gk_tab_add_type').val() == 'text') {
                add_form.find('.gk_tab_add_art').css('display', 'none');
                add_form.find('.gk_tab_add_artK2').css('display', 'none');
                add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'none');
            } else {
                add_form.find('.gk_tab_add_artK2').css('display', 'flex');
                add_form.find('.gk_tab_add_art').css('display', 'none');
                add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
                add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'none');
                add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'none');
            }
        });
        var add_form_scroll_wrap = $('#gk_tab_add_form').find('.height_scroll');

        $('#gk_tab_add_header').on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            add_form_scroll_wrap.animate({
                height: add_form.find('.gk_tab_add').outerHeight() + "px"
            },
                250,
                function () {
                    if (add_form_scroll_wrap.outerHeight() > 0)
                        add_form_scroll_wrap.css('height', 'auto');
                }
            );
        });
        var add_form_btns = add_form.find('.gk_tab_add_submit a');
        add_form_btns.eq(1).on('click', function (e) {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }

            add_form.find('.gk_tab_add_art').css('display', 'none');
            add_form.find('.gk_tab_add_artK2').css('display', 'none');
            add_form.find('.gk_tab_add_name').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_alt').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_content').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_url').parents('.control-group').css('display', 'flex');
            add_form.find('.gk_tab_add_image_width_db').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_image_gallery_directory').parents('.control-group').css('display', 'none');
            add_form.find('.gk_tab_add_name').val('');
            add_form.find('.gk_tab_add_alt').val('');
            add_form.find('.gk_tab_add_type').val('text');
            add_form.find('.gk_tab_add_image').val('');
            add_form.find('.gk_tab_add_stretch').val('nostretch');
            add_form.find('.gk_tab_add_content_access').val('public');
            add_form.find('.gk_tab_add_published').val('1');
            add_form.find('.gk_tab_add_content').val('');
            add_form.find('.gk_tab_add_url').val('');
            add_form.find('#jform_request_art_name').val('');
            add_form.find('#jform_request_art_add').val('');
            add_form.find('#jform_request_artK2_name').val('');
            add_form.find('#jform_request_artK2_add').val('');
            add_form_scroll_wrap.css('height', add_form_scroll_wrap.outerHeight() + 'px');

            add_form_scroll_wrap.animate({
                height: 0
            },
                250
            );
        });
        add_form_btns.eq(0).on('click', function (e) {
            create_item('new');

            bindMediafield();

        });
        function create_item(source, id) {
            var id = id || String(new Date().getTime());
            var item = $('#invisible').find('.gk_tab_item').clone();
            var name = (source == 'new') ? add_form.find('.gk_tab_add_name').val() : source.name;
            var alt = (source == 'new') ? add_form.find('.gk_tab_add_alt').val() : source.alt || '';
            var type = (source == 'new') ? add_form.find('.gk_tab_add_type').val() : (source.type || 'article');
            var image = (source == 'new') ? add_form.find('.gk_tab_add_image').val() : source.image;
            var stretch = (source == 'new') ? add_form.find('.gk_tab_add_stretch').val() : source.stretch;
            var video = (source == 'new') ? add_form.find('.gk_tab_add_video').val() : source.video;
            var access = (source == 'new') ? add_form.find('.gk_tab_add_content_access').val() : source.access;
            var published = (source == 'new') ? add_form.find('.gk_tab_add_published').val() : source.published;
            var content = (source == 'new') ? add_form.find('.gk_tab_add_content').val() : source.content;
            var url = (source == 'new') ? add_form.find('.gk_tab_add_url').val() : source.url;
            var image_width_db = (source == 'new') ? add_form.find('.gk_tab_add_image_width_db').val() : source.image_width_db;
            var image_directory = (source == 'new') ? add_form.find('.gk_tab_add_image_gallery_directory').val() : source.image_directory;
            var artK2_id = (source == 'new') ? add_form.find('#jform_request_artK2_add').val() : source.artK2_id;
            var artK2_title = (source == 'new') ? add_form.find('#jform_request_artK2_name').val() : source.artK2_title;
            var art_id = (source == 'new') ? add_form.find('#jform_request_art_add').val() : source.art_id;
            var art_title = (source == 'new') ? add_form.find('#jform_request_art_name').val() : source.art_title;

            item.find('#gk-article-edit-modal').prop('id', 'gk-article-edit-modal-' + id);
            item.find('.btn-open-article-modal').attr('data-bs-target', '#gk-article-edit-modal-' + id)
            Joomla.initialiseModal(item.find('#gk-article-edit-modal-' + id).get(0));

            item.find('.gk_tab_item_name').html(name);
            item.find('.gk_tab_item_type').html(type.toUpperCase());
            item.find('.gk_tab_item_state').attr('class', (published == 1) ? 'gk_tab_item_state published' : 'gk_tab_item_state unpublished');
            item.find('.gk_tab_item_state').attr('title', (published == 1) ? published_text : unpublished_text);
            item.find('.gk_tab_item_access').html((access == 'public') ? public_text : registered_text);
            item.find('.gk_tab_edit_name').val(name);
            item.find('.gk_tab_edit_alt').val(alt);
            item.find('.gk_tab_edit_type').val(type);
            item.find('.gk_tab_edit_image').val(image);
            item.find('.gk_tab_edit_stretch').val(stretch);
            item.find('.gk_tab_edit_video').val(video);
            item.find('.gk_tab_edit_content_access').val(access);
            item.find('.gk_tab_edit_published').val(published);
            item.find('.gk_tab_edit_content').val(htmlspecialchars_decode(content));
            item.find('.gk_tab_edit_url').val(url);
            item.find('.gk_tab_edit_image_width_db').val(image_width_db);
            item.find('.gk_tab_edit_image_gallery_directory').val(image_directory);
            item.find('.jform_request_edit_art').val(art_id);
            item.find('.jform_request_edit_artK2').val(artK2_id);
            item.find('.modal-art-name').val(art_title);
            item.find('.modal-artK2-name').val(artK2_title);
            item.find('.gk_tab_item_edit').on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }

                item.find('.gk_tab_item_desc').trigger('click');
            });
            item.find('.preview-image').on('click', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var modal = new tingle.modal({
                    closeMethods: ['overlay', 'button', 'escape'],
                    closeLabel: "Close",
                    cssClass: ['preview-image-modal'],
                    onClose: function () {
                        modal.destroy();
                    },
                });

                var $img = document.createElement("img");
                $img.onload = function () {
                    modal.checkOverflow();
                };
                $img.src = e.target.href;

                modal.setContent($img);
                modal.open();
            });

            item.find('.gk_tab_item_desc').on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                var scroller = item.find('.gk_tab_editor_scroll');
                scroller.css('height', scroller.outerHeight() + "px");

                if (scroller.outerHeight() > 0) {
                    scroller.animate({
                        height: 0
                    }, 250);
                } else {
                    var items = item.parent().find('.gk_tab_item');
                    items.each(function (i, it) {
                        it = $(it);
                        if (it != item)
                            it.find('.gk_tab_edit_submit a').eq(1).trigger('click');
                    });

                    scroller.animate({
                        height: scroller.find('div').outerHeight() + "px"
                    },
                        250,
                        function () {
                            if (scroller.outerHeight() > 0)
                                scroller.css('height', 'auto');
                        }
                    );

                    var temp_id = item.find('.modal-art-name').attr('id');
                    $currently_opened = temp_id.replace('jform_request_edit_art_name_', '');
                }
            });
            item.find('.gk_tab_item_state').on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                var btn = item.find('.gk_tab_item_state');
                if (btn.hasClass('published')) {
                    item.find('.gk_tab_edit_published').val(0);
                    btn.attr('class', 'gk_tab_item_state unpublished');
                    btn.attr('title', unpublished_text);
                    item.find('.gk_tab_edit_submit a').eq(0).trigger('click');
                } else {
                    item.find('.gk_tab_edit_published').val(1);
                    btn.attr('class', 'gk_tab_item_state published');
                    btn.attr('title', published_text);
                    item.find('.gk_tab_edit_submit a').eq(0).trigger('click');
                }
            });
            if (item.find('.gk_tab_edit_type').val() == 'article') {
                item.find('.gk_tab_edit_art').css('display', 'flex');
                item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_artK2').css('display', 'none');
                item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'none');
            } else if (item.find('.gk_tab_edit_type').val() == 'gallery') {
                item.find('.gk_tab_edit_artK2').css('display', 'none');
                item.find('.gk_tab_edit_art').css('display', 'none');
                item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'flex');
            } else if (item.find('.gk_tab_edit_type').val() == 'text') {
                item.find('.gk_tab_edit_artK2').css('display', 'none');
                item.find('.gk_tab_edit_art').css('display', 'none');
                item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'none');
            } else {
                item.find('.gk_tab_edit_artK2').css('display', 'flex');
                item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                item.find('.gk_tab_edit_art').css('display', 'none');
                item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'none');
                item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'none');
            }
            item.find('.gk_tab_edit_type').on('change', function () {
                if (item.find('.gk_tab_edit_type').val() == 'article') {
                    item.find('.gk_tab_edit_art').css('display', 'flex');
                    item.find('.gk_tab_edit_artK2').css('display', 'none');
                    item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'none');
                    item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'none');
                    item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'none');
                    item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'none');
                } else if (item.find('.gk_tab_edit_type').val() == 'gallery') {
                    item.find('.gk_tab_edit_artK2').css('display', 'none');
                    item.find('.gk_tab_edit_art').css('display', 'none');
                    item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'one');
                    item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'flex');
                } else if (item.find('.gk_tab_edit_type').val() == 'text') {
                    item.find('.gk_tab_edit_artK2').css('display', 'none');
                    item.find('.gk_tab_edit_art').css('display', 'none');
                    item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'none');
                    item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'none');
                } else {
                    item.find('.gk_tab_edit_artK2').css('display', 'flex');
                    item.find('.gk_tab_edit_name').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_alt').parents('.control-group').css('display', 'flex');
                    item.find('.gk_tab_edit_art').css('display', 'none');
                    item.find('.gk_tab_edit_content').parents('.control-group').css('display', 'none');
                    item.find('.gk_tab_edit_url').parents('.control-group').css('display', 'none');
                    item.find('.gk_tab_edit_image_width_db').parents('.control-group').css('display', 'none');
                    item.find('.gk_tab_edit_image_gallery_directory').parents('.control-group').css('display', 'none');
                }
            });
            item.find('.gk_tab_item_remove').on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                var items = item.parent().find('.gk_tab_item');
                var item_id = items.index(item);
                tabs.splice(item_id, 1);
                item.remove();
                $('#jform_params_image_show_data').html(JSON.stringify(tabs));
            });
            item.find('.gk_tab_edit_submit a').eq(1).on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                var scroller = item.find('.gk_tab_editor_scroll');
                scroller.css('height', scroller.outerHeight() + "px");
                scroller.animate({ height: 0 }, 250);
            });
            item.find('.gk_tab_edit_submit a').eq(0).on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                var name = item.find('.gk_tab_edit_name').val();
                var alt = item.find('.gk_tab_edit_alt').val();
                var type = item.find('.gk_tab_edit_type').val();
                var image = item.find('.gk_tab_edit_image').val();
                var stretch = item.find('.gk_tab_edit_stretch').val();
                var video = item.find('.gk_tab_edit_video').val();
                var access = item.find('.gk_tab_edit_content_access').val();
                var published = item.find('.gk_tab_edit_published').val();
                var content = item.find('.gk_tab_edit_content').val();
                var url = item.find('.gk_tab_edit_url').val();
                var image_width_db = item.find('.gk_tab_edit_image_width_db').val();
                var image_directory = item.find('.gk_tab_edit_image_gallery_directory').val();
                var art_id = item.find('.jform_request_edit_art').val();
                var art_title = item.find('.modal-art-name').val();
                var artK2_id = item.find('.jform_request_edit_artK2').val();
                var artK2_title = item.find('.modal-artK2-name').val();
                var items = item.parent().find('.gk_tab_item');
                var item_id = items.index(item);
                tabs[item_id] = { "name": name, "alt": alt, "type": type, "image": image, "stretch": stretch, "video": video, "access": access, "published": published, "content": htmlspecialchars(content), "url": url, "art_id": art_id, "art_title": art_title, "artK2_id": artK2_id, "artK2_title": artK2_title, "image_width_db": image_width_db, "image_directory": image_directory };
                item.find('.gk_tab_item_name').html(name);
                item.find('.gk_tab_item_type').html(type.toUpperCase());
                item.find('.gk_tab_item_state').attr('class', (published == 1) ? 'gk_tab_item_state published' : 'gk_tab_item_state unpublished');
                item.find('.gk_tab_item_state').attr('title', (published == 1) ? published_text : unpublished_text);
                item.find('.gk_tab_item_access').html((access == 'public') ? public_text : registered_text);
                item.find('.modal-img').attr('href', Joomla.getOptions('system.paths').root + '/' + image);
                item.find('.gk_tab_edit_submit a').eq(1).trigger('click');
                $('#jform_params_image_show_data').html(JSON.stringify(tabs));
            });
            item.find('.gk_tab_item_order_up').on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                var wrap = item.parent();
                var items = item.parent().find('.gk_tab_item');
                var item_id = items.index(item);
                if (item_id > 0) {
                    var tmp = tabs[item_id - 1];
                    tabs[item_id - 1] = tabs[item_id];
                    tabs[item_id] = tmp;
                    item.insertBefore(item.prev());
                    if (items.length > 0) {
                        wrap.find('.gk_tab_item_order_down').css('opacity', 1);
                        wrap.find('.gk_tab_item_order_up').css('opacity', 1);
                        wrap.find('.gk_tab_item_order_up').eq(0).css('opacity', 0.3);
                        wrap.find('.gk_tab_item_order_down').eq(items.length - 1).css('opacity', 0.3);
                    }
                    $('#jform_params_image_show_data').html(JSON.stringify(tabs));
                }
            });
            item.find('.gk_tab_item_order_down').on('click', function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                var wrap = item.parent();
                var items = wrap.find('.gk_tab_item');
                var item_id = items.index(item);

                if (item_id < items.length - 1) {
                    var tmp = tabs[item_id + 1];
                    tabs[item_id + 1] = tabs[item_id];
                    tabs[item_id] = tmp;
                    item.insertAfter(item.next());
                    if (items.length > 0) {
                        wrap.find('.gk_tab_item_order_down').css('opacity', 1);
                        wrap.find('.gk_tab_item_order_up').css('opacity', 1);
                        wrap.find('.gk_tab_item_order_up').eq(0).css('opacity', 0.3);
                        wrap.find('.gk_tab_item_order_down').eq(items.length - 1).css('opacity', 0.3);
                    }
                    $('#jform_params_image_show_data').html(JSON.stringify(tabs));
                }
            });
            if (source == 'new') {
                tabs.push({ "name": name, "alt": alt, "type": type, "image": image, "stretch": stretch, "video": video, "access": access, "published": published, "content": htmlspecialchars(content), "url": url, "art_id": art_id, "art_title": art_title, "artK2_id": artK2_id, "artK2_title": artK2_title, "image_width_db": image_width_db, "image_directory": image_directory });
                add_form_btns.eq(1).trigger('click');
                $('#jform_params_image_show_data').html(JSON.stringify(tabs));
            }
            item.appendTo($('#tabs_list'));
            var wrap = item.parent();
            var items = wrap.find('.gk_tab_item');
            if (items.length > 0) {
                wrap.find('.gk_tab_item_order_down').css('opacity', 1);
                wrap.find('.gk_tab_item_order_up').css('opacity', 1);
                wrap.find('.gk_tab_item_order_up').eq(0).css('opacity', 0.3);
                wrap.find('.gk_tab_item_order_down').eq([items.length - 1]).css('opacity', 0.3);
            }
            item.find('.modal-img').attr('href', Joomla.getOptions('system.paths').root + '/' + image);
            $current_slide++;
            item.find('.gk_tab_edit_image').attr('id', 'jform_params_edit_img_' + $current_slide);
            item.find('.modal-media').attr('href', 'index.php?option=com_media&view=images&tmpl=component&asset=&author=&fieldid=jform_params_edit_img_' + $current_slide + '&folder=');
            item.find('.modal-media-clear').attr('onclick', 'javascript:document.getElementById(\'jform_params_edit_img_' + $current_slide + '\').value=\'\';return false;');
            item.find('.modal-art-name').attr('id', 'jform_request_edit_art_name_' + $current_slide);
            item.find('.jform_request_edit_art').attr('id', 'jform_request_edit_art_' + $current_slide);
            item.find('.modal-artK2-name').attr('id', 'jform_request_edit_artK2_name_' + $current_slide);
            item.find('.jform_request_edit_artK2').attr('id', 'jform_request_edit_artK2_' + $current_slide);
        }

        tabs.forEach((tab, idx) => {
            create_item(tab, String(idx + 1));
        })

        $('.module_style').each(function (i, el) {
            el = $(el);
            var style_name = el.attr('id').replace('module_style_', '');
            if (config[style_name]) {
                el.find('.field').each(function (i, field) {
                    field = $(field);

                    if (config[style_name][field.attr('id')]) {
                        field.val(config[style_name][field.attr('id')]);
                    } else {
                        config[style_name][field.attr('id')] = field.val();
                    }
                });
            } else {
                config[style_name] = {};
                el.find('.field').each(function (i, field) {
                    field = $(field);
                    config[style_name][field.attr('id')] = field.val();
                });
            }
            el.find('.field').each(function (i, elm) {
                elm = $(elm);
                elm.change(function () {
                    config[style_name][elm.attr('id')] = elm.val();
                    $('#jform_params_config').html(JSON.stringify(config));
                });
                elm.blur(function () {
                    config[style_name][elm.attr('id')] = elm.val();
                    $('#jform_params_config').html(JSON.stringify(config));
                });
            });
            $('#jform_params_config').html(JSON.stringify(config));
        });

        setInterval(function () {
            $('#jform_params_last_modification').val(Math.round(new Date().getTime() / 1000));
        }, 3000);

        $('.module_style').css('display', 'none');
        $('#module_style_' + $('#jform_params_module_style').val()).css('display', 'block');
        $('#jform_params_module_style').change(function () {
            $('.module_style').css('display', 'none');
            $('#module_style_' + $('#jform_params_module_style').val()).css('display', 'block');
            checkGallery();
        });

        function checkGallery() {
            if ($('#jform_params_module_style').val() == "gk_gallery") {
                $('.gk_tab_edit_type').find("option[value=\"gallery\"]").show();
                $('.gk_tab_add_type').find("option[value=\"gallery\"]").show();
            } else {
                $('.gk_tab_edit_type').find("option[value=\"gallery\"]").hide();
                $('.gk_tab_edit_type').each(function () {
                    if ($(this).val() == 'gallery')
                        $(this).val('text').trigger('change');
                });

                $('.gk_tab_add_type').find("option[value=\"gallery\"]").hide();
            }
            $('.gk_tab_edit_submit .btn-success').trigger("click");
        }
        checkGallery();
        $('#jform_params_module_style').blur(function () {
            $('.module_style').css('display', 'none');
            $('#module_style_' + $('#jform_params_module_style').val()).css('display', 'block');
        });
        $('#gk_tab_manager').parent().css('margin-left', '5px');
        $('#gk_about_us').parent().css('margin-left', '15px');
    });
    function htmlspecialchars(string) {
        if (typeof string == 'undefined') return '';
        string = string.toString();
        string = string.replace(/&/g, '[ampersand]').replace(/</g, '[leftbracket]').replace(/>/g, '[rightbracket]');
        return string;
    }
    function htmlspecialchars_decode(string) {
        if (typeof string == 'undefined') return '';
        string = string.toString();
        string = string.replace(/\[ampersand\]/g, '&').replace(/\[leftbracket\]/g, '<').replace(/\[rightbracket\]/g, '>');
        return string;
    }
})(jQuery);

function bindMediafield() {
    return;
}