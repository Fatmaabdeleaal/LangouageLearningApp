<?php

defined('JPATH_BASE') or die;
if (!defined('DS')) {
   define('DS', DIRECTORY_SEPARATOR);
}

jimport('joomla.form.formfield');



class JFormFieldAsset extends JFormField
{
   protected $type = 'Asset';

   protected function getInput()
   {
      $doc = JFactory::getDocument();
      $doc->addStyleSheet(JURI::root() . $this->element['path'] . 'style.css');

      JHtml::_('jquery.framework');

      if (version_compare(JVERSION, '4', '<')) {
         JHtml::_('behavior.framework', true);
         JHtml::script($this->element['path'] . 'script.js');
      } else {
         JHtml::script($this->element['path'] . 'script_j4.js');
      }
   }
}
