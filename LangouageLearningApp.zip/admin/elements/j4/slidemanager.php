<?php

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\HTML\Helpers\Bootstrap;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;

defined('JPATH_BASE') or die;

class JFormFieldSlidemanager extends JFormField
{
  protected $type = 'Slidemanager';

  public function renderField($options = array())
  {
    HTMLHelper::script('https://cdnjs.cloudflare.com/ajax/libs/tingle/0.16.0/tingle.min.js');
    HTMLHelper::stylesheet('https://cdnjs.cloudflare.com/ajax/libs/tingle/0.16.0/tingle.min.css');

    $add_form = '<div id="gk_tab_manager"><div id="gk_tab_add_header">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEMS_CREATED') . '<a href="#add">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_ADD') . '</a></div><div id="gk_tab_add_form">' . $this->getForm('add') . '</div></div>';

    $edit_form = $this->getForm('edit');

    $item_form = '
    <div id="invisible">
      <div class="gk_tab_item">
        <div class="gk_tab_item_desc">
          <span class="gk_tab_item_name"></span>
          <span class="gk_tab_item_order_down" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_ORDER_DOWN') . '"></span>
          <span class="gk_tab_item_order_up" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_ORDER_UP') . '"></span>
          <a href="#remove" class="gk_tab_item_remove" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_REMOVE') . '">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_REMOVE') . '</a>
          <a href="#edit" class="gk_tab_item_edit" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_EDIT') . '">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_EDIT') . '</a>
          <span class="gk_tab_item_type"></span>
          <span class="gk_tab_item_access"></span>
          <span class="gk_tab_item_state published">
            <span>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_PUBLISHED') . '</span>
            <span>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_UNPUBLISHED') . '</span>
          </span>
          <a class="gk-modal modal-img preview-image" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_PREVIEW') . '">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ITEM_PREVIEW') . '</a>
        </div>
        <div class="gk_tab_editor_scroll">
          <div class="gk_tab_item_editor">' . $edit_form . '</div>
        </div>
      </div>
    </div>';

    $tabs_list = '<div id="tabs_list"></div>';
    $option_value = str_replace("\'", "'", $this->value);
    $option_value = str_replace(array('{\"', '\":', ':\"', '\",', ',\"', '\"}'), '"', $option_value);
    $textarea = '<textarea class="form-control" name="' . $this->name . '" id="' . $this->id . '" rows="20" cols="50">' . $option_value . '</textarea>';
    return $item_form . $add_form . $tabs_list . $textarea;
  }

  private function getForm($type = 'add')
  {

    // form_type
    $form_type_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_TYPE_TOOLTIP') . '"' : '';
    $form_type = '
    <div class="control-group">
      <div class="control-label">
        <label' . $form_type_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_TYPE') . '</label>
      </div>
      <div class="controls">
        <select class="form-control custom-select gk_tab_' . $type . '_type">
          <option value="text" selected="selected">' . JText::_('MOD_IMAGE_SHOW_GK4_TYPE_TEXT') . '</option>
          <option value="article">' . JText::_('MOD_IMAGE_SHOW_GK4_TYPE_ARTICLE') . '</option>
          <option value="k2">' . JText::_('MOD_IMAGE_SHOW_GK4_TYPE_K2') . '</option>
          <option value="gallery">' . JText::_('MOD_IMAGE_SHOW_GK4_TYPE_GALLERY') . '</option>
        </select>
      </div>
    </div>';

    // form_image
    $form_image_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_IMAGE_TOOLTIP') . '"' : '';
    $form_image = '';
    if ($type == 'add') {
      // Build the script.
      $script = array();
      $script[] = '	function jInsertFieldValue(value,id) {';
      $script[] = '		var old_id = document.getElementById(id).value;';
      $script[] = '		if (old_id != id) {';
      $script[] = '			document.getElementById(id).value = value;';
      $script[] = '		}';
      $script[] = '	}';
      // Add the script to the document head.
      JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));
      // label
      $form_image .= '<div class="control-group"><div class="control-label"><label' . $form_image_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_TYPE') . '</label></div><div class="controls">';
      // The text field.
      $form_image .= '
          <joomla-field-media class="field-media-wrapper" type="image" base-path="' . Juri::root() . '" root-folder="images" url="index.php?option=com_media&amp;tmpl=component&amp;asset=com_templates&amp;author=&amp;fieldid={field-media-id}&amp;path=" modal-container=".modal" modal-width="100%" modal-height="400px" input=".field-media-input" button-select=".button-select" button-clear=".button-clear" button-save-selected=".button-save-selected" preview="static" preview-container=".field-media-preview" preview-width="200" preview-height="200">
          <div id="imageModal_gk_tab_' . $type . '_image" role="dialog" tabindex="-1" class="joomla-modal modal fade" data-url="index.php?option=com_media&amp;tmpl=component&amp;asset=com_templates&amp;author=&amp;fieldid={field-media-id}&amp;path=" data-iframe="<iframe class=&quot;iframe&quot; src=&quot;index.php?option=com_media&amp;amp;tmpl=component&amp;amp;asset=com_templates&amp;amp;author=&amp;amp;fieldid={field-media-id}&amp;amp;path=&quot; name=&quot;Change Image&quot; height=&quot;100%&quot; width=&quot;100%&quot;></iframe>">
          <div class="modal-dialog modal-lg jviewport-width80" role="document">
            <div class="modal-content">
              <div class="modal-header">
              <h3 class="modal-title">Change Image</h3>
              <button type="button" class="btn-close novalidate" data-bs-dismiss="modal" aria-label="Close">
              </button>
          </div>
        <div class="modal-body jviewport-height60">
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary button-save-selected">Select</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
            </div>
          </div>
        </div>
              <div class="field-media-preview" style="height:auto">
               <div id="gk_tab_' . $type . '_image_preview_empty">No image selected.</div>      
               <div id="gk_tab_' . $type . '_image_preview_img"><img alt="Selected image." id="gk_tab_' . $type . '_image_preview" class="media-preview" style="max-width:200px;max-height:200px;"></div>   </div>
            <div class="input-group">
            <input name="jform[params][img]" id="jform_params_img" value="" class="gk_tab_' . $type . '_image form-control hasTooltip field-media-input" type="text">
                  <div class="input-group-btn">
                <a class="btn btn-secondary button-select">Select</a>
                <a class="btn btn-secondary hasTooltip button-clear" title="Clear"><span class="icon-remove" aria-hidden="true"></span></a>
              </div>
              </div>
        </joomla-field-media></div></div>';
    } else {
      $form_image = '';
      // label
      $form_image .= '<div class="control-group"><div class="control-label"><label' . $form_image_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_TYPE') . '</label></div><div class="controls">';
      // The text field.
      $form_image .= '
            <joomla-field-media class="field-media-wrapper" type="image" base-path="' . Juri::root() . '" root-folder="images" url="index.php?option=com_media&amp;tmpl=component&amp;asset=com_templates&amp;author=&amp;fieldid={field-media-id}&amp;path=" modal-container=".modal" modal-width="100%" modal-height="400px" input=".field-media-input" button-select=".button-select" button-clear=".button-clear" button-save-selected=".button-save-selected" preview="static" preview-container=".field-media-preview" preview-width="200" preview-height="200">
              <div id="imageModal_gk_tab_' . $type . '_image" role="dialog" tabindex="-1" class="joomla-modal modal fade" data-url="index.php?option=com_media&amp;tmpl=component&amp;asset=com_templates&amp;author=&amp;fieldid={field-media-id}&amp;path=" data-iframe="<iframe class=&quot;iframe&quot; src=&quot;index.php?option=com_media&amp;amp;tmpl=component&amp;amp;asset=com_templates&amp;amp;author=&amp;amp;fieldid={field-media-id}&amp;amp;path=&quot; name=&quot;Change Image&quot; height=&quot;100%&quot; width=&quot;100%&quot;></iframe>">
              <div class="modal-dialog modal-lg jviewport-width80" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                  <h3 class="modal-title">Change Image</h3>
                  <button type="button" class="btn-close novalidate" data-bs-dismiss="modal" aria-label="Close">
                  </button>
              </div>
            <div class="modal-body jviewport-height60">
              </div>
              <div class="modal-footer">
                <button class="btn btn-secondary button-save-selected">Select</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              </div>
                </div>
              </div>
            </div>
                  <div class="field-media-preview" style="height:auto">
                   <div id="gk_tab_' . $type . '_image_preview_empty">No image selected.</div>      <div id="gk_tab_' . $type . '_image_preview_img"><img alt="Selected image." id="gk_tab_' . $type . '_image_preview" class="media-preview" style="max-width:200px;max-height:200px;"></div>   </div>
                <div class="input-group">
                <input name="jform_params_edit_img" id="jform_params_edit_img" value="" class="gk_tab_' . $type . '_image form-control hasTooltip field-media-input" type="text">
                      <div class="input-group-btn">
                    <a class="btn btn-secondary button-select">Select</a>
                    <a class="btn btn-secondary hasTooltip button-clear" title="Clear"><span class="icon-remove" aria-hidden="true"></span></a>
                  </div>
                  </div>
            </joomla-field-media></div></div>';
    }

    // form_stretch
    $form_stretch_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_STRETCH_TOOLTIP') . '"' : '';
    $form_stretch = '<div class="control-group"><div class="control-label"><label' . $form_stretch_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_STRETCH') . '</label></div><div class="controls"><select class="form-control custom-select gk_tab_' . $type . '_stretch"><option value="nostretch" selected="selected">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_OPTION_NOSTRETCH') . '</option><option value="stretch">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_OPTION_STRETCH') . '</option></select></div></div>';

    // image_width_db
    $image_width_db_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_WIDTH_DB_TOOLTIP') . '"' : '';
    $image_width_db = '
    <div class="control-group">
      <div class="control-label">
        <label' . $image_width_db_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_WIDTH_DB') . '</label>
      </div>
      <div class="controls">
        <select class="form-control custom-select gk_tab_' . $type . '_image_width_db"><option value="0">' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_WIDTH_DB_DISABLE') . '</option><option value="1">' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_WIDTH_DB_PUBLIC') . '</option></select></p>
      </div>
    </div>';

    // image directory
    $image_width_directory_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_GALLERY_DIRECTORY') . '"' : '';
    // read directory
    $folders = JFolder::folders(JPATH_SITE . "/images", ".", true, true);
    $folderValue = [];
    foreach ($folders as $f) {
      $f = str_replace(JPATH_SITE, "", $f);
      $f = preg_replace('/^(\/|\\\\)/', "", $f);
      $folderValue[] = '<option value="' . $f . '">' . $f . '</option>';
    }
    $image_width_directory = '
    <div class="control-group">
      <div class="control-label">
        <label' . $image_width_directory_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_IMAGE_GALLERY_DIRECTORY') . '</label>
      </div>
      <div class="controls">
        <select class="form-control custom-select gk_tab_' . $type . '_image_gallery_directory">
          ' . implode(" ", $folderValue) . '
        </select>
      </div>
    </div>';

    // form_video
    $form_video_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_VIDEO_TOOLTIP') . '"' : '';
    $form_video = '<div class="control-group">';
    if ($type == 'add') {
      // Build the script.
      $script = array();
      $script[] = ' function jInsertFieldValue(value,id) {';
      $script[] = '   var old_id = document.getElementById(id).value;';
      $script[] = '   if (old_id != id) {';
      $script[] = '     document.getElementById(id).value = value;';
      $script[] = '   }';
      $script[] = ' }';
      // Add the script to the document head.
      JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));
      // label
      $form_video .= '<div class="control-label"><label' . $form_video_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_VIDEO_TYPE') . '</label></div>';
      // The text field.
      $form_video .= '<div class="controls"><input type="text" name="jform[params][video]" id="jform_params_video" value="" class="form-control form-control-success gk_tab_' . $type . '_video" /></div>';
    } else {
      // label
      $form_video .= '<div class="control-label"><label id="jform_params_edit_video_lbl"' . $form_video_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_VIDEO_TYPE') . '</label></div>';
      // The text field.
      $form_video .= '<div class="controls"><input type="text" name="jform_params_edit_video" id="jform_params_edit_video" value="" class="form-control form-control-success gk_tab_' . $type . '_video" /></div>';
    }
    $form_video .= '</div>';

    // form_access_level
    $form_access_level_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ACCESS_TOOLTIP') . '"' : '';
    $form_access_level = '<div class="control-group"><div class="control-label"><label' . $form_access_level_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ACCESS') . '</label></div><div class="controls"><select class="form-control custom-select gk_tab_' . $type . '_content_access"><option value="public">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ACCESS_PUBLIC') . '</option><option value="registered">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ACCESS_REGISTERED') . '</option></select></div></div>';

    // form_published
    $form_published_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_PUBLISHED_TOOLTIP') . '"' : '';
    $form_published = '<div class="control-group"><div class="control-label"><label' . $form_published_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_PUBLISHED') . '</label></div><div class="controls"><select class="form-control custom-select gk_tab_' . $type . '_published"><option value="1">' . JText::_('MOD_IMAGE_SHOW_GK4_PUBLISHED') . '</option><option value="0">' . JText::_('MOD_IMAGE_SHOW_GK4_UNPUBLISHED') . '</option></select></div></div>';

    // form_name
    $form_name_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_NAME_TOOLTIP') . '"' : '';
    $form_name = '<div class="control-group"><div class="control-label"><label' . $form_name_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_NAME') . '</label></div><div class="controls"><input type="text" class="form-control gk_tab_' . $type . '_name" /></div></div>';

    // form_content
    $form_content_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_CONTENT_TOOLTIP') . '"' : '';
    $form_content = '<div class="control-group"><div class="control-label"><label' . $form_content_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_CONTENT') . '</label></div><div class="controls"><textarea class="form-control gk_tab_' . $type . '_content"></textarea></div></div>';

    // form_alt
    $form_alt_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ALT_TOOLTIP') . '"' : '';
    $form_alt = '<div class="control-group"><div class="control-label"><label' . $form_alt_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ALT') . '</label></div><div class="controls"><input type="text" class="form-control gk_tab_' . $type . '_alt" /></div></div>';

    // form_url
    $form_url_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_URL_TOOLTIP') . '"' : '';
    $form_url = '<div class="control-group"><div class="control-label"><label' . $form_url_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_URL') . '</label></div><div class="controls"><input type="text" class="form-control gk_tab_' . $type . '_url" /></div></div>';
    // form_article K2
    if (ComponentHelper::isEnabled('com_k2')) {
      if ($type == 'add') {
        $form_articleK2_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ARTICLEK2_TOOLTIP') . '"' : '';
        $form_articleK2 = '
        <div class="control-group gk_tab_add_artK2">
          <div class="control-label">
            <label' . $form_articleK2_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ARTICLEK2') . '</label>
          </div>
          <div class="controls">
            <input class="form-control" type="text" id="jform_request_artK2_name" value="" disabled="disabled" size="25">
            <a class="btn gk-modal modal-art" title="Select or Change article" href="index.php?option=com_k2&amp;view=items&amp;task=element&amp;tmpl=component&amp;object=jform_request_artK2_add";function=jSelectItem_add" rel="{handler: \'iframe\', size: {x: 800, y: 450}}">Select / Change</a>
            <input type="hidden" id="jform_request_artK2_add" class="modal-value" name="jform[request][id]" value="" />
          </div>
        </div>';
      } else {
        $form_articleK2 = '
        <div class="control-group gk_tab_edit_artK2">
          <div class="control-label">
            <label>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ARTICLEK2') . '</label>
          </div>
          <div class="controls">
            <input class="form-control" type="text" class="jform_request_edit_artK2_name modal-artK2-name" value="" disabled="disabled" size="25">
            <a class="btn gk-modal modal-art" title="Select or Change article" href="index.php?option=com_k2&amp;view=items&amp;task=element&amp;tmpl=component&amp;object=jform_request_edit_artK2";function=jSelectItem2" rel="{handler: \'iframe\', size: {x: 800, y: 450}}">Select / Change</a>
            <input type="hidden" id="jform_request_edit_artK2" class="modal-value jform_request_edit_artK2" name="jform[request][id]" value="" />
          </div>
        </div>';
      }
    } else {
      $form_articleK2 = '';
    }

    // form_articlestyles
    if ($type == 'add') {
      $options = array(
        'title' => 'Select Article',
        'url' => Route::_('index.php?option=com_content&view=articles&layout=modal&tmpl=component&function=jSelectArticle_jform_request_art_add'),
        'footer' => '
          <button class="btn btn-secondary button-save-selected">Select</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        ',
        'bodyHeight' => 60,
        'height' => '100%',
        'width' => '100%',
        'isJoomla' => true,
      );
      $modalHtml = Bootstrap::renderModal('gk-article-add-modal', $options, '');
      JFactory::getDocument()->addScriptDeclaration('function jSelectArticle_jform_request_art_add(id, title, catid, object) { document.getElementById("jform_request_art_add").value = id; document.getElementById("jform_request_art_name").value = title;}');

      $form_article_tooltip = ($type == 'add') ? ' class="hasTip" title="' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ARTICLE_TOOLTIP') . '"' : '';
      $form_article = '
      <div class="control-group gk-select-article gk_tab_add_art">
        <div class="control-label">
          <label' . $form_article_tooltip . '>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ARTICLE') . '</label>
        </div>
        <div class="controls">
          <input class="form-control" type="text" id="jform_request_art_name" value="" disabled="disabled" size="25">
          <button type="button" class="btn btn-primary btn-sm btn-open-article-modal gk-modal modal-art" data-bs-target="#gk-article-add-modal" data-bs-toggle="modal" title="Select or Change article" >Select / Change</a>
          <input type="hidden" id="jform_request_art_add" class="modal-value" name="jform[request][id]" value="" />
        </div>
        ' . $modalHtml . '
      </div>';
    } else {
      $options = array(
        'title' => 'Select Article',
        'url' => Route::_('index.php?option=com_content&view=articles&layout=modal&tmpl=component&function=jSelectArticle_jform_request_edit_art'),
        'footer' => '
          <button class="btn btn-secondary button-save-selected">Select</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        ',
        'bodyHeight' => 60,
        'height' => '100%',
        'width' => '100%',
        'isJoomla' => true,
      );
      $modalHtml = Bootstrap::renderModal('gk-article-edit-modal', $options, '');
      JFactory::getDocument()->addScriptDeclaration('function jSelectArticle_jform_request_edit_art(id, title, catid, object) { document.getElementById("jform_request_edit_art_" + $currently_opened).value = id; document.getElementById("jform_request_edit_art_name_" + $currently_opened).value = title; }');

      $form_article = '
      <div class="control-group gk-select-article gk_tab_edit_art">
        <div class="control-label">
          <label>' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_ARTICLE') . '</label>
        </div>
        <div class="controls">
          <input type="text" id="jform_request_edit_art_name" class="form-control modal-art-name" value="" disabled="disabled" size="25">
          <button class="btn btn-sm btn-primary btn-open-article-modal gk-modal modal-art" type="button" data-bs-target="#gk-article-edit-modal" data-bs-toggle="modal" title="Select or Change article" >Select / Change</button>
          <input type="hidden" id="jform_request_edit_art" class="modal-value jform_request_edit_art" name="jform[request][id]" value="" />
        </div>
        ' . $modalHtml . '
      </div>';
    }

    // form_buttons
    $form_buttons = '<div class="control-group gk_tab_' . $type . '_submit"><div class="controls"><a href="#save" class="btn btn-success">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_SAVE') . '</a><a href="#cancel" class="btn btn btn-outline-danger">' . JText::_('MOD_IMAGE_SHOW_GK4_FORM_CANCEL') . '</a></div></div>';


    // create the form
    $form = '<div class="height_scroll"><div class="gk_tab_' . $type . '">' . $form_type . $form_image . $form_stretch . $form_video . $form_access_level . $image_width_db . $image_width_directory . $form_published . $form_name . $form_alt . $form_content . $form_url . $form_article . $form_articleK2 . $form_buttons . '</div></div>';

    return $form;
  }
}
